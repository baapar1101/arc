"""merge all heads final

Revision ID: b8c9286db6bd
Revises: add_workflow_tables, 9cc424e46c07, add_default_price_list_to_quick_sales, 483a0bf37370
Create Date: 2025-01-15 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b8c9286db6bd'
down_revision = (
    'add_workflow_tables',
    '9cc424e46c07', 
    'add_default_price_list_to_quick_sales',
    '483a0bf37370'
)
branch_labels = None
depends_on = None


def upgrade() -> None:
    # این یک میگریشن merge است و نیازی به کد ندارد
    pass


def downgrade() -> None:
    # این یک میگریشن merge است و نیازی به کد ندارد
    pass

